from admin import Book
from user import User

from admin_main import Admin
from user_main import Student


ch=0
if(__name__=="__main__"):
    print('''
    1.Admin Section
    2.User Section
    ''')
    ch=int(input("Enter ur choice: "))
    if(ch==1):
        username=input("Enter user name: ")
        password=int(input("Enter password: "))
        if(username=="akshu" and password==123):
            Admin()
        else:
            print("Wrong Username and Password")
    elif(ch==2):
        Student()
    else:
        print("Invalid choice")