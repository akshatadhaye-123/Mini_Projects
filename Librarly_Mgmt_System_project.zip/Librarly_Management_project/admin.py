class Book:
    count=0
    def __init__(self,id,nm,auth,status):
        Book.count+=1
        self.bid=id
        self.bnm=nm
        self.bauth=auth
        self.bstatus=status

    def __str__(self):
        return str(self.bid)+','+self.bnm+','+(self.bauth)+','+(str(self.bstatus))+','+str(self.count)

        
    '''
    def __str__(self):
        data='\nBook Id  : '+str(self.bid)
        data+='\nBook Name  : '+self.bnm
        data+='\nBook Author  : '+self.bauth
        data+='\nBook Status  : '+str(self.bstatus)
        data+='\nNumber of Book : '+str(self.count)
        return data
    '''
'''
b=Book(101,'akshu','tanu',1)
print(b)

b1=Book(102,'vedu','sany',1)
print(b1)
'''