from admin import Book
from user import User
from datetime import datetime

class BookMgmt:
    def AddBook(self,b):
        with open('book.txt','a')as fp:
            fp.write(str(b)+'\n')


    def DeleteBookById(self,id):
        allbook=[]
        found=False
        try:
            with open('book.txt','r')as fp :
                for line in fp :
                    try:
                        line.index(str(id),0,4)
                        print('Found : ',line)
                    except:
                        allbook.append(line)
                    else:
                        found=True
            if(found):
                with open('book.txt','w')as fp :
                    for book in allbook:
                        fp.write(book)
            else:
                print('File not found')
        except:
            print('File does not exist')


    def EditBookById(self,id):
        allbook=[]
        found=False
        try:
            with open('book.txt','r')as fp :
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                    except:
                        pass
                    else:
                        found=True
                        line=line.split(",")
                        print(line)
                        ans=input('Do u want to change name(y/n): ')
                        if(ans.lower()=='y'):
                            line[1]=input('Enter a name : ')
                        ans=input('Do u want to change auathor name(y/n): ')
                        if(ans.lower()=='y'):
                            line[2]=input('Enter author name: ')
                            line[2]+='\n'
                        line=','.join(line)
                    allbook.append(line)
            if(found):
                with open('book.txt','w')as fp : 
                    for e in allbook:
                        fp.write(e)
            else:
                print('Record not found ')
        except:
            print('File not present')
            return
    
    

    def showAllBook(self):
        try:
            with open('book.txt','r')as fp:
                print(fp.read())
        except:
            print('File does not exist')

    
    def searchById(self,id):
        try:
            with open('book.txt','r')as fp :
                for i in fp:
                    try:
                        i.index(str(id),0,4)
                        print('found : ',i)
                        break
                    except:
                        pass
                else:
                    print('Record not found')
        except:
            print('file does not exist')


    def searchByName(self,name):
        try:
            with open('book.txt','r')as fp : 
                for i in fp:
                    try:
                        i.lower().index(name.lower())
                        print('found : ',i)
                        break
                    except:
                        pass
                else:
                    print('Record not found')
        except:
            print('File does not exist')
            

    
    def IssueBook(self,u,id):
        try:
            allBooks = []
            found = False
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                        print("Found: ",line)
                        line = line.strip()
                        line = line.split(",") #to remove the \n
                        found = True
                        if(int(line[3])==1):
                             with open("issue.txt","a") as fp:
                               fp.write(str(u)+"\n")   
 
                        line[3] ="0\n"
                        line =",".join(line)    
                    except:
                        pass
                    finally:
                        allBooks.append(line) #all the info present in this section
                
            print(allBooks)#modified data is present in allBooks
            if(found):
              with open("book.txt","w") as fp:
                 for book in allBooks:
                    fp.write(book)
            else:
                print("not found")
        except:
            print("File not exist")

    def SubmitBook(self,id):
        try:
            allBooks=[]
            found=False
            with open("book.txt","r") as fp:
                for line in fp:
                    try:
                        found=True
                        line.index(str(id),0,4)
                        print("Found: ",line)
                        line=line.split(",")
                        if(int(line[3])==0):
                              line[3]="1\n"
                        line=",".join(line)   
                    except:
                        pass
                    finally:
                        allBooks.append(line)
                print(allBooks)
            if(found):
                with open("book.txt","w") as fp:
                    for x in allBooks:
                        fp.write(x)            
            else:
                print("Not Found")
        except:
            print("File not Exist") 

   
    def fine(self,sdate,id):
        found=False
        with open("issue.txt","r") as fp:
            for line in fp:
                try:
                    found=True
                    line.index(str(id),0,4)
                    print("Found: ",line)
                    line=line.split(",")
                    issue_date=line[1]
                    issue_date=issue_date.split("-")
                    year=int(issue_date[2])
                    month=int(issue_date[1])
                    day=int(issue_date[0])
                    issue_date=datetime(year,month,day)

                    submit_date=sdate
                    submit_date=submit_date.split("-")
                    year=int(submit_date[2])
                    month=int(submit_date[1])
                    day=int(submit_date[0])
                    submit_date=datetime(year,month,day)
                    days=(submit_date-issue_date).days
                    if(days>6):
                        f=30   
                        extra=days-6
                        fine=extra*f
                        print("U have taken",extra," days more please pay fine: ",fine,"Rs")
                    else:
                        print("U returned in proper days no need to pay fine")
                except:
                    print("Id not Found")
    
    def DeleteBookaftersubmit(self,id):
        allbook=[]
        found=False
        try:
            with open("issue.txt","r") as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,5)
                    except:
                        allbook.append(line)
                    else:
                        found=True
            if(found):
                with open("issue.txt","w") as fp:
                    for b in allbook:
                        fp.write(b)        
            else:
                print("Book not found")
        except:
            print("File Not Exist")
            return 
    