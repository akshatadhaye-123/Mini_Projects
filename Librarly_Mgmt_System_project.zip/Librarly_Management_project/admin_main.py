from admin import Book
from admin_mgmt import BookMgmt

def Admin():
    choice=0
    bookMgmt=BookMgmt()#EmpMgnt class ka object hai empMgmt
    while(choice!=6):
        print('\t\t1. Add a Book')
        print('\t\t2. Delete a Book')
        print('\t\t3. Edit existing Book')
        print('\t\t4. Search for a Book')
        print('\t\t5. Display All Book')
        print('\t\t6. Exit')

        choice=int(input('Enter a choice : '))
        if(choice==1):
            id=int(input('Enter a id : '))
            nm=input('Enter a Book name : ')
            authnm=(input('Enter Author name : '))
            sta=int(input('Enter a book status : '))
            b1=Book(id,nm,authnm,sta)#Emp class ka object
            bookMgmt.AddBook(b1)#addEmp is a function nm 
        
        elif(choice==2):
            id=int(input('Enter  a id to delete : '))
            bookMgmt.DeleteBookById(id)
        
        elif(choice==3):
            #id=int(input('Enter id to edit'))
            nm=input('Enter name to edit : ')
            bookMgmt.EditBookById(nm)
        
        elif(choice==4):
            print('\ta.Search by id ')
            print('\tb.Search by name')
            ch=input('Enter your choice(a or b)')
            if(ch.lower()=='a'):
                id=int(input('Enter id : '))
                bookMgmt.searchById(id)
            elif(ch.lower()=='b'):
                nm=input('Enter a name : ')
                bookMgmt.searchByName(nm)
            else:
                print('Invalid choice')
        elif(choice==5):
            bookMgmt.showAllBook()
        elif(choice==6):
            pass
        else:
            print('Invalid input')

        