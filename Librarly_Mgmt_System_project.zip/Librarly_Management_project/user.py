class User:
    count=0
    def __init__(self,id,nm,idate):
        self.uid=id
        self.unm=nm
        self.udate=idate
        User.count+=1
    
    def __str__(self) :
        return str(self.uid)+','+self.unm+','+str(self.udate)+','+str(self.count)
'''
u=User(1,'akshu','1-3-2000')
print(u)
'''

