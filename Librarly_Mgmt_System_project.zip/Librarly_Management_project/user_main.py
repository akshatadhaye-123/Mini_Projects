from admin_mgmt import BookMgmt
from user import User
from admin import Book

def Student():
    choice=0
    userMgmt=BookMgmt()#EmpMgnt class ka object hai empMgmt
    while(choice!=6):
        print('\t\t1. Show All Book')
        print('\t\t2. Search for a  Book')
        print('\t\t3. Issue Book')
        print('\t\t4. Subit Book')
        print('\t\t5. Exit')

        choice=int(input('Enter a choice : '))
        if(choice==1):
            userMgmt.showAllBook()
        elif(choice==2):
            print('\ta.Search by id ')
            print('\tb.Search by name')
            ch=input('Enter your choice(a or b)')
            if(ch.lower()=='a'):
                id=int(input('Enter id : '))
                userMgmt.searchById(id)
            elif(ch.lower()=='b'):
                nm=input('Enter a name : ')
                userMgmt.searchByName(nm)
            else:
                print('Invalid choice')
        elif(choice==3):
            id=int(input("Enter id : " ))
            date=input("Enter date(dd-mm-yyyy): ")
            name=input("Enter ur name: ")
            u=User(id,date,name)
            userMgmt.IssueBook(u,id)
            Book.count-=1
        elif(choice==4):
            id=int(input("Enter Book id that u want to submit"))
            userMgmt.SubmitBook(id)
            #idate=input('Enter issue date : ')
            sdate=input("Enter Submit date: ")
            userMgmt.fine(sdate,id)
            userMgmt.DeleteBookaftersubmit(id)
        elif(choice==5):
            print('Exist')

        else:
            print('Invalid input')
        

        