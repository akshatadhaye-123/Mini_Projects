class Cake:
    count=0
    def __init__(self,id,nm,price,qty):
        Cake.count+=1
        self.name=nm
        self.cprice=price
        self.cqty=qty
    def __str__(self):
        data=str(self.count)+','+self.name+','+str(self.cprice)+','+str(self.cqty)
        return data
'''
c=Cake(120,'ak',120,23)
print(c)
'''
