from admin import Cake
from mgmt import AdminMgmt
from user import User

def User_Main():

    us=AdminMgmt()
    ch=0
    while(ch!=6):
        print('\t\t1. Add to card')
        print('\t\t2. Buy cake')
        print('\t\t3. Show All Add to card cake')
        print('\t\t4. Search add to card cake ')
        print('\t\t5. Exist')
        ch=int(input('Enter a choice : '))

        if(ch==2):
            id=int(input('Enter id to buy : '))
            us.buyCake(id)

        elif(ch==1):
            id=int(input('Enter a id to serch and addnto card : '))
            us.addToCardCake(id)
        elif(ch==3):
            us.showAllAddcake()
        elif(ch==4):
            id=int(input('Enter id to search : '))
            us.searchAllAddcake(id)
        elif(ch==5):
            print('Thank you')

        else:
            print('Invalid input!!')


