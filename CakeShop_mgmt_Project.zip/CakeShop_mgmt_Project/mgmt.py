from admin import Cake
from user import User
import os

class AdminMgmt:
    def addCake(self,c):
        with open('cake.txt','a')as fp : 
            fp.write(str(c)+'\n')
        print('Number of cake is : ',Cake.count)
    def editCake(self,id):
        allcake=[]
        found=False
        try:
            with open('cake.txt','r')as fp:
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                    except:
                        pass
                    else:
                        found=True
                        line=line.split(",")
                        print(line)
                        ans=input('Do you want to change name (y/n) : ')
                        if(ans.lower()=='y'):
                            line[1]=(input('Enter name to edit : '))
                            print('Change done')
                            #print(allcake)
                        '''
                        ans=input('Do u want to quntity(y/n) : ')
                        if(ans.lower()=='y'):
                            line[3]=int(input('Enter quantity to change : '))
                            line[3]+='\n'
                        '''
                        line=",".join(line)
                    allcake.append(line)
                    #print(allcake)

            if(found):
                with open('cake.txt','w')as fp :
                    for e in allcake:
                        fp.write(e)
            else:
                print('Record not found')
            

        except:
            print('File does not exist')
            return
                     


    def deleteCake(self,id):
        allCake=[]
        found=False
        try:
            with open('cake.txt','r')as fp :
                for line in fp:
                    try:
                        line.index(str(id))
                        
                    except:
                        allCake.append(line)
                    else:
                        found=True
            if(found):
                with open('cake.txt','w')as fp : 
                    for i in allCake:
                        fp.write(i)
            else:
                print('Record not found')

        except:
            print('File not found')
            return

                        
    def searchByCakeId(self,id):
        try:
            with open('cake.txt','r')as fp :
                for line in fp:
                    try:
                        line.index(str(id),0,4)
                        print('Found : ',line)
                        break
                    except:
                        pass
                else:
                    print('Record not found')
        except:
            print('File does not exist') 
    def searchByCakeName(self,name):
        try:
            with open('cake.txt','r')as fp : 
                for i in fp :
                    try:
                        i.lower().index(name.lower())
                        print('Found : ',i)
                        break
                    except:
                        pass
                else:
                    print('Record not found')
        except:
            print('File does not present')


    def showAllCake(self):
        with open('cake.txt','r')as fp : 
            r=fp.read()
            print(r)

    def showAllAddcake(self):
        with open('card.txt','r')as fp :
            print(fp.read())

    def searchAllAddcake(self,id):
        try:
            with open('card.txt','r')as fp :
                for line in fp:
                    try:
                        line.index(str(id))
                        print('Found',line)
                        break
                    except:
                        pass
                else:
                    print('Not found')
        except:
            print('File not present')
            

    def addToCardCake(self,id):
        addcard=[]
        found=False
        try:
            with open('cake.txt','r')as fp :
                for line in fp:
                    try:
                        line.lower().index(str(id),0,4)
                    except:
                        pass
                    else:
                        found=True
                        line = line.split(",")
                        line[3]=input('Enter a new cake quantity : ')
                        line[3]+='\n'
                        line=",".join(line)
                        addcard.append(line)
            if(found):
                with open('card.txt','a')as fp:
                    for x in addcard:
                        fp.write(x)
                    print('Cake added to the card sucssfully')
            else:
                print('Record not found')
   

        except:
            print('File does not exist')

    def buyCake(self,id):
        allcake=[]
        cake=[]
        sum=0
        try:
            with open('card.txt','r')as file :
                for line in file :
                    line=line.split(',')
                    cake.append(line)
                    print('cake list is : ',cake)
                    bill=float(line[2])*int(line[3])
                    allcake.append(bill)
                    print('Total bill is : ',allcake)
                for x in allcake:
                    sum=sum+x
                print('sum is : ',sum)
            try:
                os.remove('card.txt')
            except:
                print('File not found')
            else:
                print('Bill generating sucessfully is ')
                print('\n---------------------')
                print('Cake price is : Rs ',sum)
                gst=sum*10/100
                print('gst of total : Rs',gst)
                sgst=sum*10/100
                print('Sgst is : Rs ',sgst)
                cgst=sum*(10/100)
                print('cgst is : Rs',cgst)
                total=sum+gst
                print('Total bill price is : Rs',total)
                print('------------------------------------')


                finalcakes=[]
                with open('cake.txt','r')as fp:
                    for line in fp:
                        line=line.split(',')
                        for c in cake:
                            if(c[0]==line[0]):
                                line[3]=str(int(line[3])-int(c[3]))
                        finalcakes.append(line)
                    with open('cake.txt','w')as fp:
                        for j in finalcakes:
                            fp.write(j)
        except:
            pass
            #print('Bill does not generated first add something to card')
            

     