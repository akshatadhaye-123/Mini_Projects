class User:
    count=0
    def __init__(self,nm,price,qty):
        self.name=nm
        self.cprice=price
        self.cqty=qty
        User.count+=1
    def __str__(self):
        data=str(self.count)+','+self.name+','+str(self.cprice)+','+str(self.cqty)
        return data
'''
c=User('ak',120,3)
print(c)
'''
