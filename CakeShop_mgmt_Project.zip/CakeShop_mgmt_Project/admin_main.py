from admin import Cake
from mgmt import AdminMgmt

def Admin():

    ch=0
    ad=AdminMgmt()

    while(ch!=6):
        print('\t\t1. Add cake')
        print('\t\t2. Edit cake')
        print('\t\t3. Delete cake')
        print('\t\t4. Show All cake')
        print('\t\t5. Search cake')
        print('\t\t6. Exist ')
        ch=int(input('Enter a choice : '))

        if(ch==1):
            cid=int(input('Enter cake id : '))
            cnm=input('Enter name : ')
            cprice=input('Enter price  : ')
            qty=int(input('Enter a quantity : '))
            c1=Cake(cid,cnm,cprice,qty)
            ad.addCake(c1)

        elif(ch==2):
            id=int(input('Enter id to edit : '))
            ad.editCake(id)
        elif(ch==3):
            id=int(input('Enter id to delete : '))
            ad.deleteCake(id)
        elif(ch==4):
            ad.showAllCake()
        elif(ch==5):
            print('search by id ')
            print('Search by name ')
            ch=(input('Do you want to search by id : (a/b) '))
            if(ch.lower()=='a'):
                id=int(input('Enter id to search : '))
                ad.searchByCakeId(id)
            elif(ch.lower()=='b'):
                name=input('Enter a name to search : ')
                ad.searchByCakeName(name)
            else:
                print('Invalid input ')
        elif(ch==6):
            pass

        else:
            print('Invalid input!!')


